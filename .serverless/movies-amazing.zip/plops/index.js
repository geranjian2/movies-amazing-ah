/* eslint-disable @typescript-eslint/no-var-requires */
const generateMigration = require('./generate_migration');
const generateCaseUse = require('./generate-caseuse');
module.exports = {
  generateMigration,
  generateCaseUse,
};
